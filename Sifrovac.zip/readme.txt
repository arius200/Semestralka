požadavky programu:
Mít nainstalovaný Sharpdevelop.
spuštění programu:
Spustit soubor sifrovac.sln v nainstalovaném Sharpdevelopu.
ovládání:
Program se spustí kliknutím na zelený trojúhelník v horní liště. Pak už je ovládání intuitivní.
Člověk si vyber způsob šifrování a pak zadá nebo načte text z programu a zašifruje ho popřípadě dešifruje.
Následně výsledek může vyexportovat do textového souboru k pozdějšímu použití. Textový soubor naleznete v této složce.