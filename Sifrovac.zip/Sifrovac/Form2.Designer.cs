﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 29.06.2021
 * Time: 16:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Sifrovac
{
	partial class Form2
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Button uloz1;
		private System.Windows.Forms.Button sifruj1;
		private System.Windows.Forms.Button nacti1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox5;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.uloz1 = new System.Windows.Forms.Button();
			this.sifruj1 = new System.Windows.Forms.Button();
			this.nacti1 = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Location = new System.Drawing.Point(26, 24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(339, 323);
			this.tabControl1.TabIndex = 1;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.textBox5);
			this.tabPage1.Controls.Add(this.uloz1);
			this.tabPage1.Controls.Add(this.sifruj1);
			this.tabPage1.Controls.Add(this.nacti1);
			this.tabPage1.Controls.Add(this.textBox2);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(331, 297);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Aes";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 158);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(107, 25);
			this.label3.TabIndex = 10;
			this.label3.Text = "Kontrola:";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(121, 158);
			this.textBox5.Multiline = true;
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(204, 58);
			this.textBox5.TabIndex = 9;
			// 
			// uloz1
			// 
			this.uloz1.Location = new System.Drawing.Point(111, 222);
			this.uloz1.Name = "uloz1";
			this.uloz1.Size = new System.Drawing.Size(107, 51);
			this.uloz1.TabIndex = 8;
			this.uloz1.Text = "Ulož text do souboru";
			this.uloz1.UseVisualStyleBackColor = true;
			this.uloz1.Click += new System.EventHandler(this.Uloz1Click);
			// 
			// sifruj1
			// 
			this.sifruj1.Location = new System.Drawing.Point(218, 222);
			this.sifruj1.Name = "sifruj1";
			this.sifruj1.Size = new System.Drawing.Size(107, 51);
			this.sifruj1.TabIndex = 7;
			this.sifruj1.Text = "Zašifruj";
			this.sifruj1.UseVisualStyleBackColor = true;
			this.sifruj1.Click += new System.EventHandler(this.Sifruj1Click);
			// 
			// nacti1
			// 
			this.nacti1.Location = new System.Drawing.Point(3, 222);
			this.nacti1.Name = "nacti1";
			this.nacti1.Size = new System.Drawing.Size(107, 51);
			this.nacti1.TabIndex = 6;
			this.nacti1.Text = "Načti text ze souboru";
			this.nacti1.UseVisualStyleBackColor = true;
			this.nacti1.Click += new System.EventHandler(this.Nacti1Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(121, 81);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(204, 71);
			this.textBox2.TabIndex = 4;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(121, 6);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(204, 69);
			this.textBox1.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 84);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(107, 25);
			this.label2.TabIndex = 2;
			this.label2.Text = "Zašifrovaný text:";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(107, 25);
			this.label1.TabIndex = 1;
			this.label1.Text = "Text k zašifrování:";
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(409, 422);
			this.Controls.Add(this.tabControl1);
			this.Name = "Form2";
			this.Text = "Form2";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.ResumeLayout(false);

		}
	}
}
