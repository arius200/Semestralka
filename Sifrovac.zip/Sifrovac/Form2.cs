﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 29.06.2021
 * Time: 16:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;


namespace Sifrovac
{
	/// <summary>
	/// Description of Form2.
	/// </summary>
	public partial class Form2 : Form
	{
		public static string fileContent = string.Empty;
		public string filename = "../../../Text2.txt";
		
		public Form2()
		{
			InitializeComponent();			
		}

		static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
        {
            byte[] encrypted;
            //vytvoří aes objekt s klíčem a IV
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //vypíše data do streamu
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            // vrátí zašifrované byty
            return encrypted;
        }
		static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] Key, byte[] IV)
        {
             string plaintext = null;

            //vytvoří aes objekt s klíčem a IV
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            // dešifrovaný text vloží do stringu
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }		    
            return plaintext;
         }
		
		 public static void open(){			
			var filePath = string.Empty;
			
			OpenFileDialog openFileDialog1 = new OpenFileDialog
		    {  
		        InitialDirectory = @"C:\",  
		        Title = "Browse Text Files",  
		  
		        CheckFileExists = true,  
		        CheckPathExists = true,  
		  
		        DefaultExt = "txt",  
		        Filter = "txt files (*.txt)|*.txt",  
		        FilterIndex = 2,  
		        RestoreDirectory = true,  
		  
		        ReadOnlyChecked = true,  
		        ShowReadOnly = true  
		    };  
		  
		    if (openFileDialog1.ShowDialog() == DialogResult.OK)  
		    {  
		        //získá cestu k souboru
		        filePath = openFileDialog1.FileName;
		
		        //přidá obsah souboru do streamu
		        var fileStream = openFileDialog1.OpenFile();
		
		        using (StreamReader reader = new StreamReader(fileStream))
		        {
		            fileContent = reader.ReadToEnd();
		        }
		        MessageBox.Show("Text ze souboru úspěšně načten.");
		    } 
		}

		void Sifruj1Click(object sender, EventArgs e)
		{
			using (Aes myAes = Aes.Create())
            {
                // zašifruj string do pole bytů
                byte[] encrypted = EncryptStringToBytes_Aes(textBox1.Text, myAes.Key, myAes.IV);
				textBox2.Text = Convert.ToBase64String(encrypted);
                // dešifruj pole bytů do stringu
                string roundtrip = DecryptStringFromBytes_Aes(encrypted, myAes.Key, myAes.IV);
                textBox5.Text = roundtrip;
            }
		}
		void Nacti1Click(object sender, EventArgs e)
		{
			//Form1.open();
			open();
			textBox1.Text = fileContent;
		}
		void Uloz1Click(object sender, EventArgs e)
		{
			File.WriteAllText(filename, textBox2.Text);
			MessageBox.Show("Zašifrovaný text byl uložen do " + filename + ".");
		}
	}
}
