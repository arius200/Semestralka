﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 27.06.2021
 * Time: 22:00
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Sifrovac
{
	partial class Form1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage uloz2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button sifruj1;
		private System.Windows.Forms.Button nacti1;
		private System.Windows.Forms.Button ulozr2;
		private System.Windows.Forms.Button desifruj1;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button nacti2;
		private System.Windows.Forms.Button uloz1;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Label label3;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.uloz2 = new System.Windows.Forms.TabPage();
			this.ulozr2 = new System.Windows.Forms.Button();
			this.desifruj1 = new System.Windows.Forms.Button();
			this.nacti2 = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.uloz1 = new System.Windows.Forms.Button();
			this.sifruj1 = new System.Windows.Forms.Button();
			this.nacti1 = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.uloz2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// uloz2
			// 
			this.uloz2.Controls.Add(this.ulozr2);
			this.uloz2.Controls.Add(this.desifruj1);
			this.uloz2.Controls.Add(this.nacti2);
			this.uloz2.Controls.Add(this.textBox3);
			this.uloz2.Controls.Add(this.textBox4);
			this.uloz2.Controls.Add(this.label3);
			this.uloz2.Controls.Add(this.label4);
			this.uloz2.Location = new System.Drawing.Point(4, 22);
			this.uloz2.Name = "uloz2";
			this.uloz2.Padding = new System.Windows.Forms.Padding(3);
			this.uloz2.Size = new System.Drawing.Size(331, 297);
			this.uloz2.TabIndex = 1;
			this.uloz2.Text = "Base 64 dešifruj";
			this.uloz2.UseVisualStyleBackColor = true;
			// 
			// ulozr2
			// 
			this.ulozr2.Location = new System.Drawing.Point(6, 230);
			this.ulozr2.Name = "ulozr2";
			this.ulozr2.Size = new System.Drawing.Size(107, 51);
			this.ulozr2.TabIndex = 15;
			this.ulozr2.Text = "Ulož text do souboru";
			this.ulozr2.UseVisualStyleBackColor = true;
			this.ulozr2.Click += new System.EventHandler(this.Ulozr2Click);
			// 
			// desifruj1
			// 
			this.desifruj1.Location = new System.Drawing.Point(218, 170);
			this.desifruj1.Name = "desifruj1";
			this.desifruj1.Size = new System.Drawing.Size(107, 51);
			this.desifruj1.TabIndex = 14;
			this.desifruj1.Text = "Dešifruj";
			this.desifruj1.UseVisualStyleBackColor = true;
			this.desifruj1.Click += new System.EventHandler(this.Desifruj1Click);
			// 
			// nacti2
			// 
			this.nacti2.Location = new System.Drawing.Point(6, 170);
			this.nacti2.Name = "nacti2";
			this.nacti2.Size = new System.Drawing.Size(107, 51);
			this.nacti2.TabIndex = 13;
			this.nacti2.Text = "Načti text ze souboru";
			this.nacti2.UseVisualStyleBackColor = true;
			this.nacti2.Click += new System.EventHandler(this.Nacti2Click);
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(121, 16);
			this.textBox3.Multiline = true;
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(204, 71);
			this.textBox3.TabIndex = 12;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(121, 95);
			this.textBox4.Multiline = true;
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(204, 69);
			this.textBox4.TabIndex = 9;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(6, 94);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(107, 25);
			this.label3.TabIndex = 11;
			this.label3.Text = "Dešifrovaný text:";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(6, 19);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(107, 25);
			this.label4.TabIndex = 10;
			this.label4.Text = "Text k dešifrování:";
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.uloz1);
			this.tabPage1.Controls.Add(this.sifruj1);
			this.tabPage1.Controls.Add(this.nacti1);
			this.tabPage1.Controls.Add(this.textBox2);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(331, 297);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Base64 šifruj";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// uloz1
			// 
			this.uloz1.Location = new System.Drawing.Point(8, 230);
			this.uloz1.Name = "uloz1";
			this.uloz1.Size = new System.Drawing.Size(107, 51);
			this.uloz1.TabIndex = 8;
			this.uloz1.Text = "Ulož text do souboru";
			this.uloz1.UseVisualStyleBackColor = true;
			this.uloz1.Click += new System.EventHandler(this.Uloz1Click);
			// 
			// sifruj1
			// 
			this.sifruj1.Location = new System.Drawing.Point(220, 170);
			this.sifruj1.Name = "sifruj1";
			this.sifruj1.Size = new System.Drawing.Size(107, 51);
			this.sifruj1.TabIndex = 7;
			this.sifruj1.Text = "Zašifruj";
			this.sifruj1.UseVisualStyleBackColor = true;
			this.sifruj1.Click += new System.EventHandler(this.Sifruj1Click);
			// 
			// nacti1
			// 
			this.nacti1.Location = new System.Drawing.Point(8, 170);
			this.nacti1.Name = "nacti1";
			this.nacti1.Size = new System.Drawing.Size(107, 51);
			this.nacti1.TabIndex = 6;
			this.nacti1.Text = "Načti text ze souboru";
			this.nacti1.UseVisualStyleBackColor = true;
			this.nacti1.Click += new System.EventHandler(this.Nacti1Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(121, 91);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(204, 71);
			this.textBox2.TabIndex = 4;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(121, 16);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(204, 69);
			this.textBox1.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 94);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(107, 25);
			this.label2.TabIndex = 2;
			this.label2.Text = "Zašifrovaný text:";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 19);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(107, 25);
			this.label1.TabIndex = 1;
			this.label1.Text = "Text k zašifrování:";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.uloz2);
			this.tabControl1.Location = new System.Drawing.Point(25, 25);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(339, 323);
			this.tabControl1.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(401, 461);
			this.Controls.Add(this.tabControl1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.uloz2.ResumeLayout(false);
			this.uloz2.PerformLayout();
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
