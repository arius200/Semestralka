﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 27.06.2021
 * Time: 21:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows.Forms;


namespace Sifrovac
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();			
			
		}	
					
		void Button1Click(object sender, EventArgs e)
		{
			Form1 form1 = new Form1();
			form1.Show();
		}
		void Button2Click(object sender, EventArgs e)
		{
			Form2 form2 = new Form2();
			form2.Show();
		}
		void Button3Click(object sender, EventArgs e)
		{
			Form3 form3 = new Form3();
			form3.Show();
		}
		void Button4Click(object sender, EventArgs e)
		{
			MessageBox.Show("Děkuji za vyzkoušení programu.");
			Close();
		}
	}
}
