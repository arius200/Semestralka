﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 29.06.2021
 * Time: 22:55
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows.Forms;
using System.Text;
using System.IO;
using System.Security.Cryptography;

namespace Sifrovac
{
	/// <summary>
	/// Description of Form3.
	/// </summary>
	public partial class Form3 : Form
	{
		public string filename = "../../../Text3.txt";
		public static string fileContent = string.Empty;
		
		public Form3()
		{
			InitializeComponent();

		}
		
		public string EncryptSymetric(string originalText, string password){
			//ochrany
			if(String.IsNullOrEmpty(originalText)){
				MessageBox.Show("Zadejte vstupni retezec!");
				return "";
			}
			if(password.Length != 8){
				MessageBox.Show("Sifrovaci klic musi mit delku 8 znaku!");
				return "";
			}
				
			byte[] bytes = ASCIIEncoding.Unicode.GetBytes(password);
			// vytvori instanci tridy SymetricAlgorithm
			SymmetricAlgorithm cryptoProvider = SymmetricAlgorithm.Create("TripleDES");
			// vytvorit datovy proud do pameti
			MemoryStream memoryStream = new MemoryStream();
			// sifrujici datovy proud
			CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoProvider.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
			StreamWriter writer = new StreamWriter(cryptoStream);
			
			writer.Write(originalText);
			writer.Flush();
			cryptoStream.FlushFinalBlock();
			writer.Flush();
			
			// aby byl vystup citelny, prevedeme jej pomoci Base64 na citelny ASCII text
			return Convert.ToBase64String(memoryStream.GetBuffer(), 0, (int)memoryStream.Length);
		}
		
		public string DecryptSymetric(string cryptedText, string password){
			try {
				if(String.IsNullOrEmpty(cryptedText)){
				MessageBox.Show("Zadejte vstupni retezec!");
				return "";
				}
				if(password.Length != 8){
					MessageBox.Show("Sifrovaci klic musi mit delku 8 znaku!");
					return "";
				}
				
				byte[] bytes = ASCIIEncoding.Unicode.GetBytes(password);
				TripleDESCryptoServiceProvider cryptoProvider = new TripleDESCryptoServiceProvider();
				MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(cryptedText));
				CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoProvider.CreateDecryptor(bytes, bytes), CryptoStreamMode.Read);
				StreamReader sr = new StreamReader(cryptoStream);
							
				return sr.ReadToEnd();
			} catch {
				return("Nastala chyba! Zkus to znovu.");

			}
			
		}
		public static void open(){			
			var filePath = string.Empty;
			
			OpenFileDialog openFileDialog1 = new OpenFileDialog
		    {  
		        InitialDirectory = @"C:\",  
		        Title = "Browse Text Files",  
		  
		        CheckFileExists = true,  
		        CheckPathExists = true,  
		  
		        DefaultExt = "txt",  
		        Filter = "txt files (*.txt)|*.txt",  
		        FilterIndex = 2,  
		        RestoreDirectory = true,  
		  
		        ReadOnlyChecked = true,  
		        ShowReadOnly = true  
		    };  
		  
		    if (openFileDialog1.ShowDialog() == DialogResult.OK)  
		    {  
		        //získá cestu k souboru
		        filePath = openFileDialog1.FileName;
		
		        //přidá obsah souboru do streamu
		        var fileStream = openFileDialog1.OpenFile();
		
		        using (StreamReader reader = new StreamReader(fileStream))
		        {
		            fileContent = reader.ReadToEnd();
		        }
		        MessageBox.Show("Text ze souboru úspěšně načten.");
		    } 
		}
		void Sifruj1Click(object sender, EventArgs e)
		{
			textBox2.Text = EncryptSymetric(textBox1.Text, textBox5.Text);
		}
		void Desifruj1Click(object sender, EventArgs e)
		{
			textBox4.Text = DecryptSymetric(textBox3.Text, textBox6.Text);
		}
		void Nacti1Click(object sender, EventArgs e)
		{
			open();
		    textBox1.Text = fileContent;
		}
		void Uloz1Click(object sender, EventArgs e)
		{
			File.WriteAllText(filename, textBox2.Text);
			MessageBox.Show("Zašifrovaný text byl uložen do " + filename + ".");
		}
		void Nacti2Click(object sender, EventArgs e)
		{
			open();
		    textBox3.Text = fileContent;
		}
		void Ulozr2Click(object sender, EventArgs e)
		{
			File.WriteAllText(filename, textBox4.Text);
			MessageBox.Show("Dešifrovaný text byl uložen do " + filename + ".");
		}
	}
}
