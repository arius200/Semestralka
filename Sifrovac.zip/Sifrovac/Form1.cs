﻿/*
 * Created by SharpDevelop.
 * User: rychl
 * Date: 27.06.2021
 * Time: 22:00
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows.Forms;
using System.Text;
using System.IO;

namespace Sifrovac
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	public partial class Form1 : Form
	{
		public static string fileContent = string.Empty;
		public string filename = "../../../Text.txt";
		
		public Form1()
		{
			InitializeComponent();
		}
		
		public void Encrypt64(){			
			if(textBox1.Text != null){
				byte[] bytes = Encoding.Unicode.GetBytes(textBox1.Text);
				textBox2.Text = Convert.ToBase64String(bytes);
			}else{
				MessageBox.Show("Chybí text k zašifrování!");
			}
		}
		
		public void Decrypt64(){
			if(textBox3.Text != null){
				byte[] bytes = Convert.FromBase64String(textBox3.Text);
				textBox4.Text = Encoding.Unicode.GetString(bytes);
			}else{
				MessageBox.Show("Chybí text k dešifrování!");
			}		
		}
		
		public static void open(){			
			var filePath = string.Empty;
			
			OpenFileDialog openFileDialog1 = new OpenFileDialog
		    {  
		        InitialDirectory = @"C:\",  
		        Title = "Browse Text Files",  
		  
		        CheckFileExists = true,  
		        CheckPathExists = true,  
		  
		        DefaultExt = "txt",  
		        Filter = "txt files (*.txt)|*.txt",  
		        FilterIndex = 2,  
		        RestoreDirectory = true,  
		  
		        ReadOnlyChecked = true,  
		        ShowReadOnly = true  
		    };  
		  
		    if (openFileDialog1.ShowDialog() == DialogResult.OK)  
		    {  
		        //získá cestu k souboru
		        filePath = openFileDialog1.FileName;
		
		        //přidá obsah souboru do streamu
		        var fileStream = openFileDialog1.OpenFile();
		
		        using (StreamReader reader = new StreamReader(fileStream))
		        {
		            fileContent = reader.ReadToEnd();
		        }
		        MessageBox.Show("Text ze souboru úspěšně načten.");
		    } 
		}
		void Nacti1Click(object sender, EventArgs e)
		{
			open();
		    textBox1.Text = fileContent;
		}
		void Sifruj1Click(object sender, EventArgs e)
		{
			Encrypt64();
		}
		void Uloz1Click(object sender, EventArgs e)
		{
			File.WriteAllText(filename, textBox2.Text);
			MessageBox.Show("Zašifrovaný text byl uložen do " + filename + ".");
		}

		void Desifruj1Click(object sender, EventArgs e)
		{
			Decrypt64();
		}
		void Ulozr2Click(object sender, EventArgs e)
		{
			File.WriteAllText(filename, textBox4.Text);
			MessageBox.Show("Dešifrovaný text byl uložen do " + filename + ".");
		}
		void Nacti2Click(object sender, EventArgs e)
		{
			open();
		    textBox3.Text = fileContent;
		}
	}
}
